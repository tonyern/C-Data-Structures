/*
Main.cpp
Class that runs queue.
*/

#include <iostream>
#include "Queue.h"
using namespace std;

int main()
{
	Queue<int>* testQueue = new Queue<int>(10);
	(*testQueue).enqueue(69);
	(*testQueue).enqueue(0);
	(*testQueue).enqueue(1);
	(*testQueue).enqueue(73);
	(*testQueue).enqueue(56);
	(*testQueue).enqueue(99);
	(*testQueue).enqueue(6);
	(*testQueue).enqueue(9);
	(*testQueue).enqueue(5);
	(*testQueue).enqueue(100);

	cout << "Front " << (*testQueue).peek() << endl;
	cout << "Rear " << (*testQueue).peekBack() << endl;
	cout << "Empty? " <<(*testQueue).isEmpty() << endl;
	cout << "Full? " << (*testQueue).isFull() << endl;
	cout << "Size " << (*testQueue).getSize() << endl;

	Queue<int>* copyTestQueue = new Queue<int>(*testQueue);
	cout << "Front " << (*testQueue).peek() << endl;
	cout << "Rear " << (*testQueue).peekBack() << endl;
	cout << "Empty? " << (*testQueue).isEmpty() << endl;
	cout << "Full? " << (*testQueue).isFull() << endl;
	cout << "Size " << (*testQueue).getSize() << endl;


	return 0;
}