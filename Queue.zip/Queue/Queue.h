/*
Queue.h
Queue First In First Out data structure. This will be a circular queue.
Author: Tony Nguyen
Date Created: 3/20/2018
Version: 1.0
*/

#include <iostream>
using namespace std;

template <class DT>
class Queue
{
protected:
	DT* queue;
	int size;
	DT front;
	DT rear;
public:
	// Default constructor.
	Queue();
	// Constructor that creates a queue of certain size.
	Queue(int maxSize);
	// Copy constructor.
	Queue(const Queue<DT>& other);

	// Add to queue.
	void enqueue(const DT& item);
	// Remove from queue.
	void dequeue();

	// Check if queue if full.
	bool isFull();
	// Check if queue is empty.
	bool isEmpty();

	// Overloaded equals operator.
	void operator= (const Queue<DT>& other);

	// Get size.
	int getSize() const;
	// Get element currently located in the front of the queue.
	DT peek();
	// Get element currently located in the back of the queue.
	DT peekBack();
	// Deconstructor.
	virtual ~Queue();
};

/*
Default constructor that initializes all fields to null and 0.
*/
template <class DT>
Queue<DT>::Queue()
{
	queue = NULL;
	size = 0;
	front = NULL;
	rear = NULL;
}

/*
Second constructor that creates a queue based on the given size.
@param maxSize Size passed in.
*/
template <class DT>
Queue<DT>::Queue(int maxSize)
{
	size = maxSize;
	queue = new DT[size];
	// Populate queue with null initially.
	for (int i = 0; i < size; i++)
	{
		queue[i] = NULL;
	}
	front = -1;
	rear = -1;
}

/*
Copy constructor we can use to create a new queue object with and have it populated.
@param other The Queue object to copy from.
*/
template <class DT>
Queue<DT>::Queue(const Queue<DT>& other)
{
	this->size = other.size;
	this->queue = other.queue;
	// Copy elements over.
	for (int i = 0; i < other.size; i++)
	{
		this->queue[i] = other.queue[i];
	}
	this->front = other.front;
	this->rear = other.rear;
}

/*
Add item to the queue.
@param item.
*/
template <class DT>
void Queue<DT>::enqueue(const DT& item)
{
	if (isFull())
	{
		cout << "Queue is full. Cannot add " << item << ".\n";
		return;
	}
	else if (isEmpty())
	{
		front = rear = 0;
	}
	else if (!isFull())
	{
		rear = (rear + 1) % size;
	}
	queue[rear] = item;
}

/*
Remove item from queue.
*/
template <class DT>
void Queue<DT>::dequeue()
{
	if (isEmpty())
	{
		cout << "Queue is empty. There is nothing to remove." << endl;
	}
	else if (front == rear)
	{
		rear = front = -1;
	}
	else
	{
		front = (front + 1) % size;
	}
}

/*
Overloading the equals operator.
*/
template <class DT>
void Queue<DT>::operator= (const Queue<DT>& other)
{

}

/*
Checks if queue is full or not.
@returns True or False.
*/
template <class DT>
bool Queue<DT>::isFull()
{
	return (rear + 1) % size == front ? true : false;
}

/*
Checks if queue is empty or not.
@returns True or False.
*/
template <class DT>
bool Queue<DT>::isEmpty()
{
	return (front == -1 && rear == -1);
}

/*
Get size of queue.
@return size.
*/
template <class DT>
int Queue<DT>::getSize() const
{
	return size;
}

/*
Get item located at the front of queue.
@return front or -1 If queue is empty.
*/
template <class DT>
DT Queue<DT>::peek()
{
	// Making sure queue is not empty.
	if (!isEmpty())
	{
		return queue[front];
	}
	else
	{
		cout << "There is nothing in queue." << endl;
		return -1;
	}
}

/*
Get item located at the back of queue.
@return rear or -1 If queue is empty.
*/
template <class DT>
DT Queue<DT>::peekBack()
{
	// Making sure queue is not empty.
	if (!isEmpty())
	{
		return queue[rear];
	}
	else
	{
		cout << "There is nothing in queue." << endl;
		return -1;
	}
}

/*
Deconstructor that deletes allocated memory with anything with keyword "new".
*/
template <class DT>
Queue<DT>::~Queue()
{
	// Only delete if the queue exists.
	if (queue != NULL)
	{
		for (int i = 0; i < size; i++)
		{
			queue[i] = NULL;
		}
		delete[] queue;
		size = 0;
		front = NULL;
		rear = NULL;
	}
}